#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <dos.h>
//#include <math.h>
#include <dir.h>



//#include "images\ibutton.h"
#include "images\ihelp.h"
#include "images\iplayer.h"
#include "images\ifile.h"
#include "images\inotespc.h"
#include "images\inotedot.h"

#include "images.h"

#pragma option -a-


unsigned char buff[32768];
unsigned int count;
unsigned long total;

char is_found(unsigned char val)
{
    int i;
    unsigned char *ptr;

    if (count)
    {
        ptr = &buff[0];
        for (i = 0; i < count; i++)
        {
            if (*ptr == val)
                return -1;
            ptr++;
        }
    }
    return 0;
}

void add_val(unsigned char val)
{
    buff[count] = val;
    count++;
}

void sort(unsigned char *src, unsigned int size)
{
    int i;
    unsigned char *ptr, val;

    ptr = src;
    while (size)
    {
        ptr++;
        size--;
        if (size == 0)
            break;

        val = *ptr;
        if (is_found(val) == 0)
        {
            add_val(val);
        }
        ptr++;
        size--;
        total++;
    }
}

void bin(unsigned char val)
{
    int i;
    for (i = 0; i < 8; i++)
    {
        if (val & 0x80)
            printf("1");
        else
            printf("0");
        val <<= 1;
    }
}

void show(void)
{
    int i;

    if (count == 0)
        return;

    for (i = 0; i < count; i++)
    {
        bin(buff[i]);
        printf("\n");
    }
}


int main(void)
{
    count = 0;
    total = 0;

    sort(imgHelp, imgHelp_LENGTH);
    sort(imgPlayer, imgPlayer_LENGTH);
    sort(imgFile, imgFile_LENGTH);
    sort(imgNoteSpc, imgNoteSpc_LENGTH);
    sort(imgNoteDot, imgNoteSpc_LENGTH);
    printf("total %lu bytes\n", total);
    printf("found %u attributes\n", count);
    show();
    printf("Done!\n");
    return -1;
}



