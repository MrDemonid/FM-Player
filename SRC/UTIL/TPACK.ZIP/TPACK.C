#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <dos.h>
//#include <math.h>
#include <dir.h>



#include "images\ibutton.h"
#include "images\ihelp.h"
#include "images\iplayer.h"
#include "images\ifile.h"
#include "images\inotespc.h"
#include "images\inotedot.h"

#include "images.h"


#pragma option -a-

int lineCnt;
int totalBytes;


int encode_word(unsigned int val, int length, FILE *file)
{
    unsigned char attr, symb;

    symb = val & 0xFF;
    attr = (val >> 8) & 0xFF;
    if (length)
    {
        if ((length == 1) && ((attr & 0xC0) != 0xC0))
        {
            fprintf(file, "'%c', 0x%02X", symb, attr);
            lineCnt += 9;
            // ���� ����
            /*
            if (symb >= 0x20)
            {
                fprintf(file, "'%c', 0x%02X", symb, attr);
                lineCnt += 9;
            } else {
                fprintf(file, "0x%02X, 0x%02X", symb, attr);
                lineCnt += 10;
            }
*/
            totalBytes += 2;

        } else {
            // ��᫥����⥫쭮��� ���������� ᨬ�����
            fprintf(file, "'%c', 0x%02X, 0x%02X", symb, length | 0xC0, attr);
            lineCnt += 15;
            /*
            if (symb >= 0x20)
            {
                fprintf(file, "'%c', 0x%02X, 0x%02X", symb, length | 0xC0, attr);
                lineCnt += 15;
            } else {
                fprintf(file, "0x%02X, 0x%02X, 0x%02X", symb, length | 0xC0, attr);
                lineCnt += 16;
            }
            */
            totalBytes += 3;
        }
        if (lineCnt >= (80-16))
        {
            lineCnt = 4;
            fprintf(file, ",\n    ");
        } else {
            fprintf(file, ", ");
            lineCnt += 2;
        }
    }
    return 0;
}

int encode_line(unsigned int far *linebuff, unsigned length, FILE *file)
{
    unsigned int oldVal;
    unsigned int newVal;
    unsigned int count;
    unsigned int lengthCnt;

    // ����� ����饭
    oldVal = *linebuff++;
    lengthCnt = 1;
    count = 1;
    while (lengthCnt < length)
    {
        newVal = *linebuff++;
        if (newVal == oldVal)
        {
            // ��諨 ��
            count++;
            if (count == 63)
            {
                // ���⨣�� ����. ����� �鸞
                encode_word(oldVal, count, file);
                count = 0;
            }
        } else {
            // ��� �鸞
            if (count)
            {
                // ��࠭塞 �몫�祭�� ��, � ����� �� ࠡ�⠥�
                encode_word(oldVal, count, file);
            }
            oldVal = newVal;
            count = 1;
        }
        lengthCnt++;
    }
    // ��࠭塞 �몫�祭�� ��᫥���� ��
    if (count)
    {
        encode_word(oldVal, count, file);
    }
    return 0;
}


void save(char *name, unsigned char *img, int width, int height)
{
    FILE *file;
    unsigned int *data;

    lineCnt = 4;
    totalBytes = 0;
    file = fopen(name, "wb");
    if (file)
    {
        fprintf(file, "    %i, %i,\n    ", width, height);
        // �����㥬 �����
        data = (unsigned int *) img;
        encode_line(data, width*height, file);
        fprintf(file, "\n");
    }
    fclose(file);
    printf("file: '%s',  size: %u\n", name, totalBytes);
}


int decode_line(unsigned int *linebuff, unsigned total, FILE *file)
{
    unsigned int pos;
    unsigned int color;
    unsigned int symb, attr, count;
    int i;

    pos = 0;
    while (pos < total)
    {
        symb = fgetc(file);
        attr = fgetc(file);
        count = 1;
        if ((attr & 0xC0) == 0xC0)
        {
            count = attr & 0x3F;
            attr = fgetc(file);
        }
        color = (attr << 8) | symb;
        for (i = 0; i < count; i++)
        {
            linebuff[pos++] = color;
        }
    }
    return 0;
}

void load(char *name, int length, int y)
{
    FILE *file;
    unsigned int far *vptr;
    unsigned int i, j;

    file = fopen(name, "rb");
    if (file)
    {
        vptr = MK_FP(0xB800, y*160);
        decode_line(vptr, length/2, file);
    }
    fclose(file);
}













int main(void)
{
    save("btnrel.inc", imgBtnRel, imgBtnRel_WIDTH, imgBtnRel_DEPTH);
    save("btnpush.inc", imgBtnPush, imgBtnPush_WIDTH, imgBtnPush_DEPTH);
    save("help.inc", imgHelp, imgHelp_WIDTH, imgHelp_DEPTH);
    save("player.inc", imgPlayer, imgPlayer_WIDTH, imgPlayer_DEPTH);
    save("file.inc", imgFile, imgFile_WIDTH, imgFile_DEPTH);
    save("notespc.inc", imgNoteSpc, imgNoteSpc_WIDTH, imgNoteSpc_DEPTH);
    save("notedot.inc", imgNoteDot, imgNoteDot_WIDTH, imgNoteDot_DEPTH);
/*
    load("help.img", imgHelp_LENGTH, 0);
    load("player.img", imgPlayer_LENGTH, 13);
    load("file.img", imgFile_LENGTH, 30);
//    load("notespc.img", imgNoteSpc_LENGTH);
//    load("notedot.img", imgNoteDot_LENGTH);

    asm {
        xor     ax, ax
        int     0x16
    }
*/
    printf("Done!\n");
    return -1;
}



