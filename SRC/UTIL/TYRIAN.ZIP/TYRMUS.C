#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <dos.h>
//#include <math.h>
#include <dir.h>


#pragma option -a-

/*
  ������� 䠩�� MUSIC.MUS
  0000: (2) ���. �������権
  0002: (4) array[���. �������権] of Long  // ������ ��᮫�⭠� � 䠩��
  ....
  ....
*/


/*
  ������� ���������
*/
FILE          *hfile;
unsigned short numItems;
unsigned long  filesize;
unsigned long *head;

char open_file(char *filename)
{
    unsigned long size;

    if ((hfile = fopen(filename, "rb")) == NULL)
    {
        printf("ERROR: can`t open file: %s\n", filename);
        return 0;
    }
    fread(&numItems, 1, 2, hfile);
    size = numItems * sizeof(unsigned long);
    if (size > 65000)
    {
        fclose(hfile);
        printf("ERROR: file header too long (%lu bytes)!\n", size);
        return 0;
    }
    head = malloc(size+sizeof(unsigned long));
    fread(head, 1, size, hfile);
    fseek(hfile, 0, SEEK_END);
    filesize = ftell(hfile);
    head[numItems] = filesize;
    printf("open \"%s\", size: %lu bytes\n", filesize);
    return -1;
}


/*
    nrec - ����� 䠩�� � *.MUS [0..numItems-1]
*/
void extract_file(unsigned short nrec)
{
    unsigned long offs;
    char  fname[13];
    FILE  *hdest;
    unsigned long size;
    char  *buf;

    if (nrec >= numItems)
        return;

    offs = head[nrec];
    size = head[nrec+1] - offs;
    strcpy(fname, "FILE");
    itoa(nrec, &fname[4], 10);
    strcat(fname, ".LDS");

    printf("  -rec[%u]: \"%s\" - extract %lu\ bytes at 0x%08lX\n",nrec, fname, size, offs);

    if ((hdest = fopen(fname, "wb")) != NULL)
    {
        buf = malloc(4096);
        fseek(hfile, offs, SEEK_SET);
        while (size)
        {
            if (size >= 4096)
            {
                fread(buf, 1, 4096, hfile);
                fwrite(buf, 1, 4096, hdest);
                size = size - 4096;
            } else {
                fread(buf, 1, size, hfile);
                fwrite(buf, 1, size, hdest);
                size = 0;
            }
        }
        free(buf);
        fclose(hdest);
    } else {
        printf("  -ERROR: can`t create file: %s\n", fname);
    }
}


int main(int argc, char *argv[])
{
    int i;

    if (argc != 2)
    {
        printf("Usage: tyrmus.exe music.mus\n");
        return 0;
    }
    if (open_file(argv[1]))
    {
        for (i = 0; i < numItems; i++)
            extract_file(i);

        fclose(hfile);
    }
    printf("Done!\n");
    return -1;
}


