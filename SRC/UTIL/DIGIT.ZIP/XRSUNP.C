#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <dos.h>
//#include <math.h>
#include <dir.h>


#pragma option -a-

/*
  ������� 䠩�� *.XRS
  0000: (2) ���. �������権
  0002: (4) array[���. �������権] of HITEM
  ....
  ....
  XXXX: datas
*/



/*
  ������� ���������
*/
typedef struct
{
    char            fname[13];          // ��� 䠩�� (pascal string)
    unsigned long   offs;               // offs+datas = absolute position
    unsigned long   size;
    char            dummy[11];
} HITEM;


FILE          *hfile;
unsigned short numItems;
unsigned long  stoffs;
HITEM         *head;


char open_file(char *filename)
{
    unsigned long size;

    if ((hfile = fopen(filename, "rb")) == NULL)
    {
        printf("ERROR: can`t open file: %s\n", filename);
        return 0;
    }
    fread(&numItems, 1, 2, hfile);
    size = numItems * sizeof(HITEM);
    if (size > 65000)
    {
        fclose(hfile);
        printf("ERROR: file header too long (%lu bytes)!\n", size);
        return 0;
    }
    head = malloc(size);
    fread(head, size, 1, hfile);
    stoffs = ftell(hfile);
    printf("  -offset: 0x%lX\n", stoffs);
    return -1;
}


void pas_to_c(char *dst, char *src)
{
    unsigned char len = *src;
    char *sptr = src;
    char *dptr = dst;

    sptr++;
    while (len)
    {
        *dptr++ = *sptr++;
        len--;
    }
    *dptr = 0;
}

/*
    nrec - ����� 䠩�� � *.XRF [0..numItems-1]
*/
void extract_file(unsigned short nrec)
{
    HITEM *cur;
    char  fname[13];
    FILE  *hdest;
    unsigned long size;
    char  *buf;

    if (nrec >= numItems)
        return;
    cur = &head[nrec];
    pas_to_c(fname, cur->fname);
    printf("  -rec[%u]: \"%s\" ",nrec, fname);

    if ((hdest = fopen(fname, "wb")) != NULL)
    {
        buf = malloc(4096);
        size = cur->size;
        fseek(hfile, cur->offs + stoffs, SEEK_SET);
        while (size)
        {
            if (size >= 4096)
            {
                fread(buf, 1, 4096, hfile);
                fwrite(buf, 1, 4096, hdest);
                size = size - 4096;
            } else {
                fread(buf, 1, size, hfile);
                fwrite(buf, 1, size, hdest);
                size = 0;
            }
        }
        free(buf);
        fclose(hdest);
        printf(" - extract %lu\ bytes at 0x%08lX\n", cur->size, (unsigned long)cur->offs+stoffs);
    } else {
        printf("\n  -ERROR: can`t create file: %s\n", fname);
    }
}


int main(int argc, char *argv[])
{
    int i;

    if (argc != 2)
    {
        printf("Usage: xrsunp.exe filename.xrs\n");
        return 0;
    }
    if (open_file(argv[1]))
    {
        for (i = 0; i < numItems; i++)
            extract_file(i);

        fclose(hfile);
    }
    printf("Done!\n");
    return -1;
}


